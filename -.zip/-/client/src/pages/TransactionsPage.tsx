import { useState } from "react";
import AppLayout from "@/components/AppLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Plus, Filter, Download, ArrowUpRight, ArrowDownRight, Calendar } from "lucide-react";
import { Progress } from "@/components/ui/progress";

export default function TransactionsPage() {
  const [dateFilter, setDateFilter] = useState("11/2025");
  const [accountFilter, setAccountFilter] = useState("all");

  const transactions = [
    {
      id: 1,
      date: "08/11/2025",
      description: "Recebido",
      category: "Receita",
      value: 850.00,
      type: "income",
    },
    {
      id: 2,
      date: "08/11/2025",
      description: "Pago",
      category: "Despesa Operacional",
      value: -680.00,
      type: "expense",
    },
    {
      id: 3,
      date: "07/11/2025",
      description: "Previsto",
      category: "Receita",
      value: 850.00,
      type: "income",
    },
  ];

  const summary = {
    income: 850.00,
    expenses: -680.00,
    balance: 170.00,
  };

  const incomePercentage = 100;
  const expensePercentage = (Math.abs(summary.expenses) / summary.income) * 100;

  return (
    <AppLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Transações</h1>
            <p className="text-muted-foreground">
              Gerencie todas as suas transações financeiras
            </p>
          </div>
          <Button className="gap-2">
            <Plus className="h-4 w-4" />
            Adicionar
          </Button>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Previsto / realizado no mês</CardTitle>
              <p className="text-sm text-muted-foreground">Novembro/2025 - Conta Principal</p>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Recebidos</span>
                  <span className="text-sm font-semibold text-green-600">{incomePercentage.toFixed(0)}%</span>
                </div>
                <div className="relative h-20 w-20 mx-auto">
                  <svg className="transform -rotate-90 w-20 h-20">
                    <circle
                      cx="40"
                      cy="40"
                      r="32"
                      stroke="currentColor"
                      strokeWidth="8"
                      fill="transparent"
                      className="text-muted"
                    />
                    <circle
                      cx="40"
                      cy="40"
                      r="32"
                      stroke="currentColor"
                      strokeWidth="8"
                      fill="transparent"
                      strokeDasharray={`${incomePercentage * 2.01} ${200}`}
                      className="text-green-500"
                    />
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="text-lg font-bold text-green-600">{incomePercentage.toFixed(0)}%</span>
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Pago</span>
                  <span className="text-sm font-semibold text-red-600">{expensePercentage.toFixed(0)}%</span>
                </div>
                <div className="relative h-20 w-20 mx-auto">
                  <svg className="transform -rotate-90 w-20 h-20">
                    <circle
                      cx="40"
                      cy="40"
                      r="32"
                      stroke="currentColor"
                      strokeWidth="8"
                      fill="transparent"
                      className="text-muted"
                    />
                    <circle
                      cx="40"
                      cy="40"
                      r="32"
                      stroke="currentColor"
                      strokeWidth="8"
                      fill="transparent"
                      strokeDasharray={`${expensePercentage * 2.01} ${200}`}
                      className="text-red-500"
                    />
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="text-lg font-bold text-red-600">{expensePercentage.toFixed(0)}%</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Resumo do Período</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-green-50 dark:bg-green-950/20 rounded-lg">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Recebido</p>
                  <p className="text-2xl font-bold text-green-600">
                    R$ {summary.income.toLocaleString("pt-BR", {
                      minimumFractionDigits: 2,
                    })}
                  </p>
                </div>
                <ArrowDownRight className="h-8 w-8 text-green-500" />
              </div>

              <div className="flex items-center justify-between p-4 bg-red-50 dark:bg-red-950/20 rounded-lg">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Pago</p>
                  <p className="text-2xl font-bold text-red-600">
                    R$ {Math.abs(summary.expenses).toLocaleString("pt-BR", {
                      minimumFractionDigits: 2,
                    })}
                  </p>
                </div>
                <ArrowUpRight className="h-8 w-8 text-red-500" />
              </div>

              <div className="flex items-center justify-between p-4 bg-primary/5 rounded-lg border-2 border-primary/20">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Previsão de mês</p>
                  <p className={`text-2xl font-bold ${summary.balance >= 0 ? "text-green-600" : "text-red-600"}`}>
                    R$ {summary.balance.toLocaleString("pt-BR", {
                      minimumFractionDigits: 2,
                    })}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
              <CardTitle>Lançamentos</CardTitle>
              <div className="flex flex-wrap gap-2 w-full sm:w-auto">
                <Select value={dateFilter} onValueChange={setDateFilter}>
                  <SelectTrigger className="w-[140px]">
                    <SelectValue placeholder="Período" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="11/2025">NOV/2025</SelectItem>
                    <SelectItem value="10/2025">OUT/2025</SelectItem>
                    <SelectItem value="09/2025">SET/2025</SelectItem>
                  </SelectContent>
                </Select>

                <Select value={accountFilter} onValueChange={setAccountFilter}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Conta" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todas as contas</SelectItem>
                    <SelectItem value="main">Conta Principal</SelectItem>
                    <SelectItem value="savings">Poupança</SelectItem>
                  </SelectContent>
                </Select>

                <Button variant="outline" className="gap-2">
                  <Filter className="h-4 w-4" />
                  Filtrar
                </Button>

                <Button variant="outline" className="gap-2">
                  <Download className="h-4 w-4" />
                  Exportar
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {transactions.length > 0 ? (
                <>
                  <div className="hidden sm:grid grid-cols-12 gap-4 text-sm font-medium text-muted-foreground border-b pb-2">
                    <div className="col-span-2">Data</div>
                    <div className="col-span-4">Descrição</div>
                    <div className="col-span-3">Categoria</div>
                    <div className="col-span-3 text-right">Valor</div>
                  </div>

                  {transactions.map((transaction) => (
                    <div
                      key={transaction.id}
                      className="grid grid-cols-1 sm:grid-cols-12 gap-2 sm:gap-4 p-4 sm:p-0 border sm:border-0 rounded-lg sm:rounded-none hover:bg-muted/50 transition-colors cursor-pointer"
                    >
                      <div className="col-span-12 sm:col-span-2 text-sm">
                        <span className="sm:hidden font-medium">Data: </span>
                        {transaction.date}
                      </div>
                      <div className="col-span-12 sm:col-span-4 font-medium">
                        <span className="sm:hidden text-muted-foreground">Descrição: </span>
                        {transaction.description}
                      </div>
                      <div className="col-span-12 sm:col-span-3 text-sm">
                        <span className="sm:hidden font-medium">Categoria: </span>
                        <Badge variant="outline">{transaction.category}</Badge>
                      </div>
                      <div className="col-span-12 sm:col-span-3 text-right">
                        <span
                          className={`font-semibold ${
                            transaction.type === "income"
                              ? "text-green-600"
                              : "text-red-600"
                          }`}
                        >
                          {transaction.type === "income" ? "+" : "-"} R${" "}
                          {Math.abs(transaction.value).toLocaleString("pt-BR", {
                            minimumFractionDigits: 2,
                          })}
                        </span>
                      </div>
                    </div>
                  ))}
                </>
              ) : (
                <div className="text-center py-12">
                  <p className="text-muted-foreground">Nenhuma transação encontrada</p>
                  <Button className="mt-4 gap-2">
                    <Plus className="h-4 w-4" />
                    Adicionar primeira transação
                  </Button>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
}
