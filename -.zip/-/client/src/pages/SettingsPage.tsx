import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import AppLayout from "@/components/AppLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Building, User } from "lucide-react";

interface Organization {
  id: string;
  name: string;
  email: string | null;
  phone: string | null;
  document: string | null;
  address: string | null;
  city: string | null;
  state: string | null;
  zipCode: string | null;
}

export default function SettingsPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [orgFormData, setOrgFormData] = useState({
    name: "",
    email: "",
    phone: "",
    document: "",
    address: "",
    city: "",
    state: "",
    zipCode: "",
  });

  const { data: organization, isLoading } = useQuery<Organization>({
    queryKey: ["/api/organizations/current"],
    queryFn: async () => {
      const res = await fetch("/api/organizations/current", { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch organization");
      return res.json();
    },
  });

  useEffect(() => {
    if (organization) {
      setOrgFormData({
        name: organization.name,
        email: organization.email || "",
        phone: organization.phone || "",
        document: organization.document || "",
        address: organization.address || "",
        city: organization.city || "",
        state: organization.state || "",
        zipCode: organization.zipCode || "",
      });
    }
  }, [organization]);

  const updateOrganizationMutation = useMutation({
    mutationFn: async (data: typeof orgFormData) => {
      if (!organization) throw new Error("No organization");
      const res = await fetch(`/api/organizations/${organization.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to update organization");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/organizations/current"] });
      toast({ title: "Organização atualizada com sucesso!" });
    },
    onError: () => {
      toast({ variant: "destructive", title: "Erro ao atualizar organização" });
    },
  });

  const handleSubmitOrganization = (e: React.FormEvent) => {
    e.preventDefault();
    updateOrganizationMutation.mutate(orgFormData);
  };

  if (isLoading) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center p-12">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Configurações</h1>
          <p className="text-muted-foreground">
            Gerencie as configurações da sua conta e organização
          </p>
        </div>

        <Tabs defaultValue="organization" className="space-y-6">
          <TabsList>
            <TabsTrigger value="organization" className="gap-2">
              <Building className="h-4 w-4" />
              Organização
            </TabsTrigger>
            <TabsTrigger value="account" className="gap-2">
              <User className="h-4 w-4" />
              Conta
            </TabsTrigger>
          </TabsList>

          <TabsContent value="organization">
            <Card>
              <CardHeader>
                <CardTitle>Informações da Organização</CardTitle>
                <CardDescription>
                  Atualize as informações da sua empresa
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmitOrganization} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="org-name">Nome da Organização *</Label>
                    <Input
                      id="org-name"
                      value={orgFormData.name}
                      onChange={(e) => setOrgFormData({ ...orgFormData, name: e.target.value })}
                      required
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="org-email">Email</Label>
                      <Input
                        id="org-email"
                        type="email"
                        value={orgFormData.email}
                        onChange={(e) => setOrgFormData({ ...orgFormData, email: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="org-phone">Telefone</Label>
                      <Input
                        id="org-phone"
                        value={orgFormData.phone}
                        onChange={(e) => setOrgFormData({ ...orgFormData, phone: e.target.value })}
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="org-document">CNPJ</Label>
                    <Input
                      id="org-document"
                      value={orgFormData.document}
                      onChange={(e) => setOrgFormData({ ...orgFormData, document: e.target.value })}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="org-address">Endereço</Label>
                    <Input
                      id="org-address"
                      value={orgFormData.address}
                      onChange={(e) => setOrgFormData({ ...orgFormData, address: e.target.value })}
                    />
                  </div>

                  <div className="grid grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="org-city">Cidade</Label>
                      <Input
                        id="org-city"
                        value={orgFormData.city}
                        onChange={(e) => setOrgFormData({ ...orgFormData, city: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="org-state">Estado</Label>
                      <Input
                        id="org-state"
                        value={orgFormData.state}
                        onChange={(e) => setOrgFormData({ ...orgFormData, state: e.target.value })}
                        maxLength={2}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="org-zipCode">CEP</Label>
                      <Input
                        id="org-zipCode"
                        value={orgFormData.zipCode}
                        onChange={(e) => setOrgFormData({ ...orgFormData, zipCode: e.target.value })}
                      />
                    </div>
                  </div>

                  <div className="flex justify-end">
                    <Button type="submit" disabled={updateOrganizationMutation.isPending}>
                      {updateOrganizationMutation.isPending && (
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      )}
                      Salvar Alterações
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="account">
            <Card>
              <CardHeader>
                <CardTitle>Configurações da Conta</CardTitle>
                <CardDescription>
                  Gerencie suas informações pessoais e preferências
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Configurações de conta em desenvolvimento. Em breve você poderá atualizar sua senha,
                  foto de perfil e preferências de notificação.
                </p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
}
